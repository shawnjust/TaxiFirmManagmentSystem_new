﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TaxiFirm.Controllers
{
    public class FrontPageController : Controller
    {
        //
        // GET: /FrontPage/

        public ActionResult Index() 
        {
            return View();
        }
        public ActionResult News()
        {
            return View();
        }
        public ActionResult Notification()
        {
            return View();
        }
        public ActionResult Gallery()
        {
            return View();
        }
        public ActionResult About()
        {

            return View();
        }
        public ActionResult Elements()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult NewsContent()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult Complain()
        {
            return View();
        }
        public ActionResult ErrorPage()
        {
            return View();
        }
    }
}
