﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TaxiFirm.Models;
namespace TaxiFirm.Controllers
{
    public class HandleController : Controller
    {
        //
        // GET: /Handle/
       

    }
}
